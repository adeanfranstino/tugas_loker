package com.kerjakuy.app;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.kerjakuy.app.database.DatabaseHelper;

public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout tilNama, tilEmail, tilPassword, tilKonfirmasi;
    private TextInputEditText etNama, etEmail, etPassword, etKonfirmasi;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DatabaseHelper(this);
        tilNama = findViewById(R.id.tilNama);
        tilEmail = findViewById(R.id.tilEmail);
        tilPassword = findViewById(R.id.tilPassword);
        tilKonfirmasi = findViewById(R.id.tilKonfirmasi);
        etNama = findViewById(R.id.etNama);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etKonfirmasi = findViewById(R.id.etKonfirmasi);

        findViewById(R.id.btnRegister).setOnClickListener(v -> prosesDaftar());
        findViewById(R.id.tvLogin).setOnClickListener(v -> finish());
    }

    private String teks(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString();
    }

    private void prosesDaftar() {
        String nama = teks(etNama).trim();
        String email = teks(etEmail).trim().toLowerCase();
        String pass = teks(etPassword);
        String konfirmasi = teks(etKonfirmasi);
        boolean valid = true;

        tilNama.setError(null);
        tilEmail.setError(null);
        tilPassword.setError(null);
        tilKonfirmasi.setError(null);

        if (nama.isEmpty()) {
            tilNama.setError("Nama wajib diisi");
            valid = false;
        }
        if (email.isEmpty()) {
            tilEmail.setError("Email wajib diisi");
            valid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Format email tidak valid");
            valid = false;
        }
        if (pass.length() < 6) {
            tilPassword.setError("Password minimal 6 karakter");
            valid = false;
        }
        if (!pass.equals(konfirmasi)) {
            tilKonfirmasi.setError("Konfirmasi password tidak sama");
            valid = false;
        }
        if (!valid) return;

        if (db.emailAda(email)) {
            tilEmail.setError("Email sudah terdaftar");
            return;
        }
        if (db.registerUser(nama, email, pass)) {
            Toast.makeText(this, "Registrasi berhasil, silakan login", Toast.LENGTH_LONG).show();
            finish();
        } else {
            Toast.makeText(this, "Registrasi gagal, coba lagi", Toast.LENGTH_SHORT).show();
        }
    }
}
