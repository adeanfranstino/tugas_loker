package com.kerjakuy.app;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.kerjakuy.app.database.DatabaseHelper;
import com.kerjakuy.app.model.Lowongan;
import com.kerjakuy.app.util.SessionManager;
import com.kerjakuy.app.util.UiHelper;

public class DetailLowonganActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "extra_id";

    private DatabaseHelper db;
    private String email;
    private Lowongan lowongan;
    private ImageView ivFavorit;
    private MaterialButton btnLamar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_lowongan);

        db = new DatabaseHelper(this);
        email = new SessionManager(this).getEmail();

        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        lowongan = db.getLowonganById(id, email);
        if (lowongan == null) {
            Toast.makeText(this, "Data lowongan tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        ivFavorit = findViewById(R.id.ivFavorit);
        btnLamar = findViewById(R.id.btnLamar);

        UiHelper.pasangLogo((TextView) findViewById(R.id.tvLogo), lowongan.perusahaan);
        ((TextView) findViewById(R.id.tvPosisi)).setText(lowongan.posisi);
        ((TextView) findViewById(R.id.tvPerusahaan)).setText(lowongan.perusahaan);
        ((TextView) findViewById(R.id.tvLokasi)).setText(lowongan.lokasi);
        ((TextView) findViewById(R.id.tvGaji)).setText(lowongan.gaji);
        ((TextView) findViewById(R.id.tvJenis)).setText(lowongan.jenis);
        ((TextView) findViewById(R.id.tvDeskripsi)).setText(lowongan.deskripsi);

        StringBuilder sb = new StringBuilder();
        for (String s : lowongan.persyaratan.split("\\|")) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("•  ").append(s.trim());
        }
        ((TextView) findViewById(R.id.tvPersyaratan)).setText(sb.toString());

        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        ivFavorit.setOnClickListener(v -> {
            lowongan.favorit = db.toggleFavorit(email, lowongan.id);
            perbaruiIkonFavorit();
            Toast.makeText(this, lowongan.favorit ? "Ditambahkan ke favorit" : "Dihapus dari favorit",
                    Toast.LENGTH_SHORT).show();
        });

        btnLamar.setOnClickListener(v -> konfirmasiLamar());

        perbaruiIkonFavorit();
        perbaruiTombolLamar();
    }

    private void perbaruiIkonFavorit() {
        ivFavorit.setImageResource(lowongan.favorit ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);
    }

    private void perbaruiTombolLamar() {
        if (db.sudahDilamar(email, lowongan.id)) {
            btnLamar.setText("Sudah Dilamar");
            btnLamar.setEnabled(false);
        } else {
            btnLamar.setText("Lamar Sekarang");
            btnLamar.setEnabled(true);
        }
    }

    private void konfirmasiLamar() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Konfirmasi Lamaran")
                .setMessage("Kirim lamaran untuk posisi " + lowongan.posisi + " di " + lowongan.perusahaan + "?")
                .setPositiveButton("Ya, Lamar", (d, w) -> {
                    if (db.tambahLamaran(email, lowongan.id)) {
                        Toast.makeText(this, "Lamaran berhasil disimpan", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "Kamu sudah melamar posisi ini", Toast.LENGTH_SHORT).show();
                    }
                    perbaruiTombolLamar();
                })
                .setNegativeButton("Batal", null)
                .show();
    }
}
