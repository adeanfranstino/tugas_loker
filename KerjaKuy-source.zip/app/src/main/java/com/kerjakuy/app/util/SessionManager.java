package com.kerjakuy.app.util;

import android.content.Context;
import android.content.SharedPreferences;

/** Menyimpan status login dan info CV memakai SharedPreferences. */
public class SessionManager {
    private static final String PREF = "kerjakuy_session";
    private final SharedPreferences sp;

    public SessionManager(Context context) {
        sp = context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void login(String email) {
        sp.edit().putBoolean("logged_in", true).putString("email", email).apply();
    }

    public void logout() {
        sp.edit().putBoolean("logged_in", false).remove("email").apply();
    }

    public boolean isLoggedIn() {
        return sp.getBoolean("logged_in", false) && !getEmail().isEmpty();
    }

    public String getEmail() {
        return sp.getString("email", "");
    }

    public void saveCv(String uri, String nama) {
        sp.edit().putString("cv_uri_" + getEmail(), uri)
                .putString("cv_name_" + getEmail(), nama).apply();
    }

    public String getCvName() {
        return sp.getString("cv_name_" + getEmail(), null);
    }
}
