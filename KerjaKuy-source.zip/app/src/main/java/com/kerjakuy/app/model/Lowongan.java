package com.kerjakuy.app.model;

public class Lowongan {
    public int id;
    public String posisi;
    public String perusahaan;
    public String lokasi;
    public String gaji;
    public String jenis;
    public String kategori;
    public String deskripsi;
    public String persyaratan;      // dipisahkan tanda "|"
    public boolean favorit;

    // Hanya terisi untuk daftar "Lamaran Saya"
    public int lamaranId;
    public String status;
    public String tanggal;
}
