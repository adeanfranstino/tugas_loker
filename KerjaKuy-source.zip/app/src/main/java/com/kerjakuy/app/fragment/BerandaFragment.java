package com.kerjakuy.app.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.kerjakuy.app.DetailLowonganActivity;
import com.kerjakuy.app.R;
import com.kerjakuy.app.adapter.AdapterLowongan;
import com.kerjakuy.app.database.DatabaseHelper;
import com.kerjakuy.app.model.Lowongan;
import com.kerjakuy.app.util.SessionManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BerandaFragment extends Fragment implements AdapterLowongan.Listener {

    private static final String[] KATEGORI = {"Semua", "IT", "Admin", "Desain", "Marketing",
            "Layanan Pelanggan", "Keuangan", "Teknik", "Ritel", "HRD"};
    private static final String[] LOKASI = {"Semua Lokasi", "Medan", "Jakarta", "Bandung",
            "Surabaya", "Yogyakarta", "Remote"};
    private static final String[] JENIS = {"Semua Jenis", "Full-time", "Part-time", "Magang", "Kontrak"};

    private DatabaseHelper db;
    private String email;
    private AdapterLowongan adapter;
    private final List<Lowongan> semua = new ArrayList<>();
    private String kategoriDipilih = "Semua";

    private EditText etCari;
    private Spinner spLokasi, spJenis;
    private TextView tvKosong;

    public BerandaFragment() {
        super(R.layout.fragment_beranda);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = new DatabaseHelper(requireContext());
        email = new SessionManager(requireContext()).getEmail();

        etCari = view.findViewById(R.id.etCari);
        spLokasi = view.findViewById(R.id.spLokasi);
        spJenis = view.findViewById(R.id.spJenis);
        tvKosong = view.findViewById(R.id.tvKosong);
        ChipGroup chipGroup = view.findViewById(R.id.chipGroup);
        RecyclerView rv = view.findViewById(R.id.rvLowongan);

        // Sapaan
        String[] user = db.getUser(email);
        String nama = (user != null && !user[0].isEmpty()) ? user[0] : "Pengguna";
        String depan = nama.split(" ")[0];
        ((TextView) view.findViewById(R.id.tvSapaan)).setText("Halo, " + depan + "! 👋");

        // RecyclerView
        adapter = new AdapterLowongan(this, false);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(adapter);

        // Chip kategori
        for (String k : KATEGORI) {
            Chip chip = (Chip) getLayoutInflater().inflate(R.layout.item_chip, chipGroup, false);
            chip.setText(k);
            chip.setId(View.generateViewId());
            chipGroup.addView(chip);
            if (k.equals("Semua")) chip.setChecked(true);
        }
        chipGroup.setOnCheckedStateChangeListener((group, ids) -> {
            if (ids.isEmpty()) {
                kategoriDipilih = "Semua";
            } else {
                Chip c = group.findViewById(ids.get(0));
                kategoriDipilih = c.getText().toString();
            }
            terapkanFilter();
        });

        // Spinner
        spLokasi.setAdapter(buatAdapter(LOKASI));
        spJenis.setAdapter(buatAdapter(JENIS));
        AdapterView.OnItemSelectedListener filterListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                terapkanFilter();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };
        spLokasi.setOnItemSelectedListener(filterListener);
        spJenis.setOnItemSelectedListener(filterListener);

        // Pencarian
        etCari.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                terapkanFilter();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private ArrayAdapter<String> buatAdapter(String[] data) {
        ArrayAdapter<String> a = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, data);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Muat ulang agar status favorit selalu terbaru setelah kembali dari halaman detail
        semua.clear();
        semua.addAll(db.getAllLowongan(email));
        terapkanFilter();
    }

    private void terapkanFilter() {
        if (adapter == null) return;
        String q = etCari.getText().toString().trim().toLowerCase(Locale.ROOT);
        int posLokasi = spLokasi.getSelectedItemPosition();
        int posJenis = spJenis.getSelectedItemPosition();
        String lokasi = spLokasi.getSelectedItem() == null ? "" : spLokasi.getSelectedItem().toString();
        String jenis = spJenis.getSelectedItem() == null ? "" : spJenis.getSelectedItem().toString();

        List<Lowongan> hasil = new ArrayList<>();
        for (Lowongan l : semua) {
            boolean cocokCari = q.isEmpty()
                    || l.posisi.toLowerCase(Locale.ROOT).contains(q)
                    || l.perusahaan.toLowerCase(Locale.ROOT).contains(q)
                    || l.kategori.toLowerCase(Locale.ROOT).contains(q);
            boolean cocokKategori = kategoriDipilih.equals("Semua") || l.kategori.equals(kategoriDipilih);
            boolean cocokLokasi = posLokasi <= 0 || l.lokasi.equals(lokasi);
            boolean cocokJenis = posJenis <= 0 || l.jenis.equals(jenis);
            if (cocokCari && cocokKategori && cocokLokasi && cocokJenis) hasil.add(l);
        }
        adapter.setData(hasil);
        tvKosong.setVisibility(hasil.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onItemClick(Lowongan l, int position) {
        Intent i = new Intent(requireContext(), DetailLowonganActivity.class);
        i.putExtra(DetailLowonganActivity.EXTRA_ID, l.id);
        startActivity(i);
    }

    @Override
    public void onFavoritClick(Lowongan l, int position) {
        l.favorit = db.toggleFavorit(email, l.id);
        adapter.ubah(position);
    }
}
