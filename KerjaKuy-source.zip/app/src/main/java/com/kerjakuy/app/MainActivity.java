package com.kerjakuy.app;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.kerjakuy.app.fragment.BerandaFragment;
import com.kerjakuy.app.fragment.FavoritFragment;
import com.kerjakuy.app.fragment.LamaranFragment;
import com.kerjakuy.app.fragment.ProfilFragment;
import com.kerjakuy.app.util.SessionManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Pengaman: jika belum login, kembali ke halaman login
        if (!new SessionManager(this).isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);
        BottomNavigationView nav = findViewById(R.id.bottomNav);

        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment f;
            if (id == R.id.nav_beranda) f = new BerandaFragment();
            else if (id == R.id.nav_favorit) f = new FavoritFragment();
            else if (id == R.id.nav_lamaran) f = new LamaranFragment();
            else f = new ProfilFragment();

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, f)
                    .commit();
            return true;
        });

        if (savedInstanceState == null) {
            nav.setSelectedItemId(R.id.nav_beranda);
        }
    }
}
