package com.kerjakuy.app.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.kerjakuy.app.model.Lowongan;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "kerjakuy.db";
    private static final int DB_VERSION = 1;

    public static final String STATUS_TERKIRIM = "Terkirim";
    public static final String STATUS_DIPROSES = "Diproses";
    public static final String STATUS_DITERIMA = "Diterima";

    public DatabaseHelper(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (email TEXT PRIMARY KEY, nama TEXT, password TEXT, telepon TEXT, lokasi TEXT)");
        db.execSQL("CREATE TABLE lowongan (id INTEGER PRIMARY KEY AUTOINCREMENT, posisi TEXT, perusahaan TEXT, lokasi TEXT, gaji TEXT, jenis TEXT, kategori TEXT, deskripsi TEXT, persyaratan TEXT)");
        db.execSQL("CREATE TABLE favorit (email TEXT, job_id INTEGER, PRIMARY KEY (email, job_id))");
        db.execSQL("CREATE TABLE lamaran (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, job_id INTEGER, status TEXT, tanggal TEXT, UNIQUE (email, job_id))");
        isiDataContoh(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS lowongan");
        db.execSQL("DROP TABLE IF EXISTS favorit");
        db.execSQL("DROP TABLE IF EXISTS lamaran");
        onCreate(db);
    }

    // ====================== DATA LOWONGAN (SIMULASI) ======================
    private void tambah(SQLiteDatabase db, String posisi, String perusahaan, String lokasi,
                        String gaji, String jenis, String kategori, String deskripsi, String syarat) {
        ContentValues v = new ContentValues();
        v.put("posisi", posisi);
        v.put("perusahaan", perusahaan);
        v.put("lokasi", lokasi);
        v.put("gaji", gaji);
        v.put("jenis", jenis);
        v.put("kategori", kategori);
        v.put("deskripsi", deskripsi);
        v.put("persyaratan", syarat);
        db.insert("lowongan", null, v);
    }

    private void isiDataContoh(SQLiteDatabase db) {
        tambah(db, "Junior Android Developer", "PT Nusantara Teknologi", "Medan", "Rp 6.000.000 - 9.000.000", "Full-time", "IT",
                "Mengembangkan dan memelihara aplikasi Android menggunakan Java/Kotlin, bekerja sama dengan tim desain dan backend.",
                "Minimal D3/S1 Teknik Informatika|Menguasai Java dan Android Studio|Memahami RecyclerView dan SQLite|Mampu bekerja dalam tim");
        tambah(db, "Web Developer (Laravel)", "CV Mitra Digital", "Bandung", "Rp 7.000.000 - 10.000.000", "Full-time", "IT",
                "Membangun website dan REST API untuk klien menggunakan framework Laravel dan MySQL.",
                "Pengalaman minimal 1 tahun dengan PHP/Laravel|Memahami MySQL dan Git|Bisa membuat REST API|Teliti dan bertanggung jawab");
        tambah(db, "Magang IT Support", "PT Sinar Data Utama", "Medan", "Rp 1.500.000", "Magang", "IT",
                "Membantu tim IT dalam perawatan komputer, jaringan kantor, dan penanganan keluhan pengguna.",
                "Mahasiswa aktif jurusan IT/Komputer|Memahami dasar jaringan komputer|Bersedia magang minimal 3 bulan|Komunikatif dan mau belajar");
        tambah(db, "Admin Perkantoran", "PT Karya Sejahtera", "Medan", "Rp 3.500.000 - 4.500.000", "Full-time", "Admin",
                "Mengelola surat-menyurat, arsip dokumen, dan jadwal kegiatan kantor.",
                "Minimal SMK/D3 Administrasi|Menguasai Microsoft Word dan Excel|Rapi dan teliti|Berdomisili di Medan");
        tambah(db, "Admin Gudang", "PT Logistik Prima", "Surabaya", "Rp 4.000.000 - 5.000.000", "Kontrak", "Admin",
                "Mencatat barang masuk dan keluar, mengelola stok, serta membuat laporan gudang harian.",
                "Minimal SMA/SMK|Menguasai Excel dasar|Jujur dan teliti|Bersedia bekerja dengan sistem shift");
        tambah(db, "Desainer Grafis", "Kreasi Visual Studio", "Yogyakarta", "Rp 4.500.000 - 6.500.000", "Full-time", "Desain",
                "Membuat desain media sosial, poster, logo, dan materi promosi untuk berbagai klien.",
                "Menguasai Adobe Photoshop dan Illustrator atau Figma|Memiliki portofolio desain|Kreatif dan memahami tren visual|Mampu bekerja sesuai tenggat");
        tambah(db, "UI/UX Designer", "PT Pixel Kreatif", "Remote", "Rp 6.000.000 - 9.000.000", "Kontrak", "Desain",
                "Merancang wireframe dan prototype aplikasi mobile dan web berdasarkan riset pengguna.",
                "Menguasai Figma|Memahami prinsip UX dan Material Design|Memiliki studi kasus portofolio|Komunikasi yang baik");
        tambah(db, "Digital Marketing Specialist", "PT Pasar Online Indonesia", "Jakarta", "Rp 6.000.000 - 8.500.000", "Full-time", "Marketing",
                "Mengelola iklan digital, SEO, dan media sosial untuk meningkatkan penjualan produk.",
                "Pengalaman minimal 1 tahun di digital marketing|Memahami Meta Ads dan Google Ads|Mampu membaca data analitik|Kreatif dan analitis");
        tambah(db, "Content Creator Part-time", "Toko Kopi Nusantara", "Medan", "Rp 2.000.000 - 3.000.000", "Part-time", "Marketing",
                "Membuat konten foto dan video pendek untuk Instagram dan TikTok kedai kopi.",
                "Bisa mengedit video sederhana|Memiliki akun media sosial aktif|Kreatif dan up to date tren|Bersedia bekerja 4 jam per hari");
        tambah(db, "Customer Service", "PT Layanan Prima", "Jakarta", "Rp 4.200.000 - 5.000.000", "Full-time", "Layanan Pelanggan",
                "Melayani pertanyaan dan keluhan pelanggan melalui telepon dan email dengan ramah.",
                "Minimal D3 semua jurusan|Komunikasi lisan dan tulisan yang baik|Sabar dan ramah|Bersedia bekerja shift");
        tambah(db, "Customer Service Chat (Remote)", "Belanja Cepat", "Remote", "Rp 3.800.000 - 4.500.000", "Kontrak", "Layanan Pelanggan",
                "Membalas chat pelanggan di marketplace dan membantu proses pengembalian barang.",
                "Mengetik cepat dan rapi|Memiliki laptop dan internet stabil|Teliti dan responsif|Pengalaman CS menjadi nilai tambah");
        tambah(db, "Staf Akuntansi", "KAP Mandiri Jaya", "Surabaya", "Rp 5.000.000 - 7.000.000", "Full-time", "Keuangan",
                "Menyusun laporan keuangan, jurnal, dan rekonsiliasi bank serta membantu pelaporan pajak.",
                "Minimal S1 Akuntansi|Memahami standar akuntansi dan perpajakan dasar|Menguasai Excel dan software akuntansi|Teliti dan jujur");
        tambah(db, "Teknisi Listrik", "PT Daya Teknik", "Medan", "Rp 4.500.000 - 6.000.000", "Full-time", "Teknik",
                "Melakukan instalasi, perawatan, dan perbaikan sistem kelistrikan gedung dan pabrik.",
                "Minimal SMK Teknik Listrik|Memahami diagram kelistrikan|Mampu bekerja di ketinggian|Memiliki SIM C");
        tambah(db, "Teknisi Jaringan", "PT Konek Nusantara", "Bandung", "Rp 5.000.000 - 7.000.000", "Kontrak", "Teknik",
                "Memasang dan memelihara jaringan internet pelanggan serta mengatasi gangguan koneksi.",
                "Memahami dasar jaringan dan konfigurasi router|Memiliki sertifikat MikroTik (nilai plus)|Bersedia kerja lapangan|Memiliki SIM C");
        tambah(db, "Kasir", "Minimarket Sumber Rejeki", "Medan", "Rp 2.800.000 - 3.500.000", "Part-time", "Ritel",
                "Melayani transaksi pembayaran, menata barang di rak, dan menjaga kebersihan toko.",
                "Minimal SMA/SMK|Jujur dan teliti dalam menghitung uang|Ramah kepada pelanggan|Bersedia bekerja shift pagi atau sore");
        tambah(db, "Staf HRD", "PT Bina Insani", "Jakarta", "Rp 5.500.000 - 7.500.000", "Full-time", "HRD",
                "Mengelola rekrutmen, administrasi karyawan, absensi, dan penggajian.",
                "Minimal S1 Psikologi/Manajemen|Memahami dasar hukum ketenagakerjaan|Komunikatif dan menjaga kerahasiaan data|Pengalaman rekrutmen menjadi nilai tambah");
    }

    // ====================== AKUN ======================
    private String hash(String teks) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(teks.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return teks;
        }
    }

    public boolean emailAda(String email) {
        Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM users WHERE email=?", new String[]{email});
        boolean ada = c.moveToFirst();
        c.close();
        return ada;
    }

    /** @return false jika email sudah terdaftar atau gagal menyimpan */
    public boolean registerUser(String nama, String email, String password) {
        if (emailAda(email)) return false;
        ContentValues v = new ContentValues();
        v.put("email", email);
        v.put("nama", nama);
        v.put("password", hash(password));
        v.put("telepon", "");
        v.put("lokasi", "");
        return getWritableDatabase().insert("users", null, v) != -1;
    }

    public boolean cekLogin(String email, String password) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT 1 FROM users WHERE email=? AND password=?", new String[]{email, hash(password)});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    /** @return {nama, email, telepon, lokasi} atau null */
    public String[] getUser(String email) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT nama, email, telepon, lokasi FROM users WHERE email=?", new String[]{email});
        String[] hasil = null;
        if (c.moveToFirst()) {
            hasil = new String[]{
                    c.isNull(0) ? "" : c.getString(0),
                    c.getString(1),
                    c.isNull(2) ? "" : c.getString(2),
                    c.isNull(3) ? "" : c.getString(3)};
        }
        c.close();
        return hasil;
    }

    public void updateProfil(String email, String nama, String telepon, String lokasi) {
        ContentValues v = new ContentValues();
        v.put("nama", nama);
        v.put("telepon", telepon);
        v.put("lokasi", lokasi);
        getWritableDatabase().update("users", v, "email=?", new String[]{email});
    }

    // ====================== LOWONGAN ======================
    private Lowongan baca(Cursor c) {
        Lowongan l = new Lowongan();
        l.id = c.getInt(c.getColumnIndexOrThrow("id"));
        l.posisi = c.getString(c.getColumnIndexOrThrow("posisi"));
        l.perusahaan = c.getString(c.getColumnIndexOrThrow("perusahaan"));
        l.lokasi = c.getString(c.getColumnIndexOrThrow("lokasi"));
        l.gaji = c.getString(c.getColumnIndexOrThrow("gaji"));
        l.jenis = c.getString(c.getColumnIndexOrThrow("jenis"));
        l.kategori = c.getString(c.getColumnIndexOrThrow("kategori"));
        l.deskripsi = c.getString(c.getColumnIndexOrThrow("deskripsi"));
        l.persyaratan = c.getString(c.getColumnIndexOrThrow("persyaratan"));
        int i = c.getColumnIndex("fav");
        if (i >= 0) l.favorit = c.getInt(i) > 0;
        i = c.getColumnIndex("lamaran_id");
        if (i >= 0) {
            l.lamaranId = c.getInt(i);
            l.status = c.getString(c.getColumnIndexOrThrow("status"));
            l.tanggal = c.getString(c.getColumnIndexOrThrow("tanggal"));
        }
        return l;
    }

    private static final String FAV_SUB =
            "(SELECT COUNT(*) FROM favorit f WHERE f.email=? AND f.job_id=l.id) AS fav";

    private List<Lowongan> query(String sql, String[] args) {
        List<Lowongan> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(sql, args);
        while (c.moveToNext()) list.add(baca(c));
        c.close();
        return list;
    }

    public List<Lowongan> getAllLowongan(String email) {
        return query("SELECT l.*, " + FAV_SUB + " FROM lowongan l ORDER BY l.id", new String[]{email});
    }

    public Lowongan getLowonganById(int id, String email) {
        List<Lowongan> list = query("SELECT l.*, " + FAV_SUB + " FROM lowongan l WHERE l.id=?",
                new String[]{email, String.valueOf(id)});
        return list.isEmpty() ? null : list.get(0);
    }

    // ====================== FAVORIT ======================
    public List<Lowongan> getFavorit(String email) {
        return query("SELECT l.*, 1 AS fav FROM lowongan l INNER JOIN favorit f ON f.job_id=l.id " +
                "WHERE f.email=? ORDER BY l.id", new String[]{email});
    }

    public boolean isFavorit(String email, int jobId) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT 1 FROM favorit WHERE email=? AND job_id=?", new String[]{email, String.valueOf(jobId)});
        boolean ada = c.moveToFirst();
        c.close();
        return ada;
    }

    /** @return true jika sekarang menjadi favorit, false jika dihapus dari favorit */
    public boolean toggleFavorit(String email, int jobId) {
        SQLiteDatabase w = getWritableDatabase();
        if (isFavorit(email, jobId)) {
            w.delete("favorit", "email=? AND job_id=?", new String[]{email, String.valueOf(jobId)});
            return false;
        }
        ContentValues v = new ContentValues();
        v.put("email", email);
        v.put("job_id", jobId);
        w.insert("favorit", null, v);
        return true;
    }

    // ====================== LAMARAN ======================
    public boolean sudahDilamar(String email, int jobId) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT 1 FROM lamaran WHERE email=? AND job_id=?", new String[]{email, String.valueOf(jobId)});
        boolean ada = c.moveToFirst();
        c.close();
        return ada;
    }

    /** @return false jika sudah pernah melamar atau gagal menyimpan */
    public boolean tambahLamaran(String email, int jobId) {
        if (sudahDilamar(email, jobId)) return false;
        String tgl = new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID")).format(new Date());
        ContentValues v = new ContentValues();
        v.put("email", email);
        v.put("job_id", jobId);
        v.put("status", STATUS_TERKIRIM);
        v.put("tanggal", tgl);
        return getWritableDatabase().insert("lamaran", null, v) != -1;
    }

    public List<Lowongan> getLamaran(String email) {
        return query("SELECT l.*, " + FAV_SUB + ", a.id AS lamaran_id, a.status AS status, a.tanggal AS tanggal " +
                        "FROM lamaran a INNER JOIN lowongan l ON l.id=a.job_id WHERE a.email=? ORDER BY a.id DESC",
                new String[]{email, email});
    }

    public void updateStatus(int lamaranId, String status) {
        ContentValues v = new ContentValues();
        v.put("status", status);
        getWritableDatabase().update("lamaran", v, "id=?", new String[]{String.valueOf(lamaranId)});
    }
}
