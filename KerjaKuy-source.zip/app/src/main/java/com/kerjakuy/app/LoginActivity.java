package com.kerjakuy.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.kerjakuy.app.database.DatabaseHelper;
import com.kerjakuy.app.util.SessionManager;

public class LoginActivity extends AppCompatActivity {

    private static final String DEMO_EMAIL = "demo@kerjakuy.com";
    private static final String DEMO_PASS = "demo123";

    private TextInputLayout tilEmail, tilPassword;
    private TextInputEditText etEmail, etPassword;
    private DatabaseHelper db;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        tilEmail = findViewById(R.id.tilEmail);
        tilPassword = findViewById(R.id.tilPassword);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        MaterialButton btnLogin = findViewById(R.id.btnLogin);
        MaterialButton btnDemo = findViewById(R.id.btnDemo);

        btnLogin.setOnClickListener(v -> prosesLogin());
        btnDemo.setOnClickListener(v -> masukDemo());
        findViewById(R.id.tvRegister).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    private String teks(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString();
    }

    private void prosesLogin() {
        String email = teks(etEmail).trim().toLowerCase();
        String pass = teks(etPassword);
        boolean valid = true;

        tilEmail.setError(null);
        tilPassword.setError(null);

        if (email.isEmpty()) {
            tilEmail.setError("Email wajib diisi");
            valid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Format email tidak valid");
            valid = false;
        }
        if (pass.isEmpty()) {
            tilPassword.setError("Password wajib diisi");
            valid = false;
        }
        if (!valid) return;

        if (db.cekLogin(email, pass)) {
            masuk(email);
        } else {
            Toast.makeText(this, "Email atau password salah", Toast.LENGTH_SHORT).show();
        }
    }

    private void masukDemo() {
        if (!db.emailAda(DEMO_EMAIL)) {
            db.registerUser("Pengguna Demo", DEMO_EMAIL, DEMO_PASS);
        }
        masuk(DEMO_EMAIL);
    }

    private void masuk(String email) {
        session.login(email);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
