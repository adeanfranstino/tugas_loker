package com.kerjakuy.app.util;

import android.content.Context;
import android.content.res.ColorStateList;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;

import com.kerjakuy.app.R;
import com.kerjakuy.app.database.DatabaseHelper;

import java.util.Locale;

public class UiHelper {
    private static final int[] WARNA = {
            0xFF2563EB, 0xFF7C3AED, 0xFF059669, 0xFFEA580C, 0xFFDB2777, 0xFF0891B2
    };

    /** Mengambil huruf pertama nama perusahaan (tanpa awalan PT/CV). */
    public static String inisial(String nama) {
        String s = nama == null ? "" : nama.trim();
        if (s.startsWith("PT ") || s.startsWith("CV ")) s = s.substring(3).trim();
        return s.isEmpty() ? "?" : s.substring(0, 1).toUpperCase(Locale.ROOT);
    }

    /** Membuat "logo" lingkaran berwarna dengan huruf awal perusahaan. */
    public static void pasangLogo(TextView tv, String perusahaan) {
        tv.setText(inisial(perusahaan));
        int warna = WARNA[Math.abs(perusahaan.hashCode() % WARNA.length)];
        ViewCompat.setBackgroundTintList(tv, ColorStateList.valueOf(warna));
    }

    public static int warnaStatus(Context c, String status) {
        if (DatabaseHelper.STATUS_DITERIMA.equals(status)) {
            return ContextCompat.getColor(c, R.color.success);
        } else if (DatabaseHelper.STATUS_DIPROSES.equals(status)) {
            return ContextCompat.getColor(c, R.color.warning);
        }
        return ContextCompat.getColor(c, R.color.primary);
    }
}
