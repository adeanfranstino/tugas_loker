package com.kerjakuy.app.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kerjakuy.app.DetailLowonganActivity;
import com.kerjakuy.app.R;
import com.kerjakuy.app.adapter.AdapterLowongan;
import com.kerjakuy.app.database.DatabaseHelper;
import com.kerjakuy.app.model.Lowongan;
import com.kerjakuy.app.util.SessionManager;

import java.util.List;

public class FavoritFragment extends Fragment implements AdapterLowongan.Listener {

    private DatabaseHelper db;
    private String email;
    private AdapterLowongan adapter;
    private TextView tvKosong;

    public FavoritFragment() {
        super(R.layout.fragment_favorit);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = new DatabaseHelper(requireContext());
        email = new SessionManager(requireContext()).getEmail();
        tvKosong = view.findViewById(R.id.tvKosong);

        RecyclerView rv = view.findViewById(R.id.rvDaftar);
        adapter = new AdapterLowongan(this, false);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        List<Lowongan> data = db.getFavorit(email);
        adapter.setData(data);
        tvKosong.setVisibility(data.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onItemClick(Lowongan l, int position) {
        Intent i = new Intent(requireContext(), DetailLowonganActivity.class);
        i.putExtra(DetailLowonganActivity.EXTRA_ID, l.id);
        startActivity(i);
    }

    @Override
    public void onFavoritClick(Lowongan l, int position) {
        db.toggleFavorit(email, l.id);     // di halaman ini, tekan hati = hapus dari favorit
        adapter.hapus(position);
        if (db.getFavorit(email).isEmpty()) tvKosong.setVisibility(View.VISIBLE);
    }
}
