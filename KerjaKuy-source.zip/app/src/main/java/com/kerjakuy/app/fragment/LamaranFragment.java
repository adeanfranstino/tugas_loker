package com.kerjakuy.app.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.kerjakuy.app.DetailLowonganActivity;
import com.kerjakuy.app.R;
import com.kerjakuy.app.adapter.AdapterLowongan;
import com.kerjakuy.app.database.DatabaseHelper;
import com.kerjakuy.app.model.Lowongan;
import com.kerjakuy.app.util.SessionManager;

import java.util.List;

public class LamaranFragment extends Fragment implements AdapterLowongan.Listener {

    private DatabaseHelper db;
    private String email;
    private AdapterLowongan adapter;
    private TextView tvKosong;

    public LamaranFragment() {
        super(R.layout.fragment_lamaran);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = new DatabaseHelper(requireContext());
        email = new SessionManager(requireContext()).getEmail();
        tvKosong = view.findViewById(R.id.tvKosong);

        RecyclerView rv = view.findViewById(R.id.rvDaftar);
        adapter = new AdapterLowongan(this, true);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        muat();
    }

    private void muat() {
        List<Lowongan> data = db.getLamaran(email);
        adapter.setData(data);
        tvKosong.setVisibility(data.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onItemClick(Lowongan l, int position) {
        String[] opsi = {"Lihat detail lowongan", "Ubah status (simulasi)"};
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(l.posisi)
                .setItems(opsi, (d, which) -> {
                    if (which == 0) {
                        Intent i = new Intent(requireContext(), DetailLowonganActivity.class);
                        i.putExtra(DetailLowonganActivity.EXTRA_ID, l.id);
                        startActivity(i);
                    } else {
                        pilihStatus(l);
                    }
                })
                .show();
    }

    // Karena tidak ada server, status diubah manual untuk keperluan demo.
    private void pilihStatus(Lowongan l) {
        String[] status = {DatabaseHelper.STATUS_TERKIRIM, DatabaseHelper.STATUS_DIPROSES,
                DatabaseHelper.STATUS_DITERIMA};
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Ubah status lamaran")
                .setItems(status, (d, which) -> {
                    db.updateStatus(l.lamaranId, status[which]);
                    muat();
                })
                .show();
    }

    @Override
    public void onFavoritClick(Lowongan l, int position) {
        l.favorit = db.toggleFavorit(email, l.id);
        adapter.ubah(position);
    }
}
