package com.kerjakuy.app.fragment;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.kerjakuy.app.LoginActivity;
import com.kerjakuy.app.R;
import com.kerjakuy.app.database.DatabaseHelper;
import com.kerjakuy.app.util.SessionManager;
import com.kerjakuy.app.util.UiHelper;

public class ProfilFragment extends Fragment {

    private DatabaseHelper db;
    private SessionManager session;
    private TextView tvAvatar, tvNama, tvEmail, tvTelepon, tvLokasi, tvCv;

    // Pemilih file CV (Storage Access Framework, tanpa izin storage)
    private final ActivityResultLauncher<Intent> cvLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK
                        && result.getData() != null && result.getData().getData() != null) {
                    Uri uri = result.getData().getData();
                    try {
                        requireContext().getContentResolver().takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {
                        // Tidak masalah; kita hanya menyimpan nama file
                    }
                    new SessionManager(requireContext()).saveCv(uri.toString(), namaFile(uri));
                    tampilCv();
                    Toast.makeText(requireContext(), "CV berhasil dipilih", Toast.LENGTH_SHORT).show();
                }
            });

    public ProfilFragment() {
        super(R.layout.fragment_profil);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = new DatabaseHelper(requireContext());
        session = new SessionManager(requireContext());

        tvAvatar = view.findViewById(R.id.tvAvatar);
        tvNama = view.findViewById(R.id.tvNama);
        tvEmail = view.findViewById(R.id.tvEmail);
        tvTelepon = view.findViewById(R.id.tvTelepon);
        tvLokasi = view.findViewById(R.id.tvLokasi);
        tvCv = view.findViewById(R.id.tvCv);

        view.findViewById(R.id.btnPilihCv).setOnClickListener(v -> pilihCv());
        view.findViewById(R.id.btnEdit).setOnClickListener(v -> dialogEdit());
        view.findViewById(R.id.btnLogout).setOnClickListener(v -> konfirmasiLogout());
    }

    @Override
    public void onResume() {
        super.onResume();
        tampilProfil();
        tampilCv();
    }

    private void tampilProfil() {
        String[] u = db.getUser(session.getEmail());
        if (u == null) return;
        tvNama.setText(u[0].isEmpty() ? "Pengguna" : u[0]);
        tvEmail.setText(u[1]);
        tvAvatar.setText(UiHelper.inisial(u[0].isEmpty() ? "U" : u[0]));
        tvTelepon.setText(u[2].isEmpty() ? "Belum diisi" : u[2]);
        tvLokasi.setText(u[3].isEmpty() ? "Belum diisi" : u[3]);
    }

    private void tampilCv() {
        String nama = session.getCvName();
        tvCv.setText(nama == null ? "Belum ada CV" : nama);
    }

    private void pilihCv() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/pdf",
                    "application/msword",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"});
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            cvLauncher.launch(i);
        } catch (Exception e) {
            Toast.makeText(requireContext(), "Tidak dapat membuka pemilih file", Toast.LENGTH_SHORT).show();
        }
    }

    private String namaFile(Uri uri) {
        String nama = "CV";
        try (Cursor c = requireContext().getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) nama = c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        return nama;
    }

    private void dialogEdit() {
        String[] u = db.getUser(session.getEmail());
        if (u == null) return;

        View form = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_edit_profil, null);
        TextInputEditText etNama = form.findViewById(R.id.etNama);
        TextInputEditText etTelepon = form.findViewById(R.id.etTelepon);
        TextInputEditText etLokasi = form.findViewById(R.id.etLokasi);
        etNama.setText(u[0]);
        etTelepon.setText(u[2]);
        etLokasi.setText(u[3]);

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Edit Profil")
                .setView(form)
                .setPositiveButton("Simpan", null)   // di-override supaya dialog tidak menutup jika input salah
                .setNegativeButton("Batal", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String nama = etNama.getText() == null ? "" : etNama.getText().toString().trim();
            String telepon = etTelepon.getText() == null ? "" : etTelepon.getText().toString().trim();
            String lokasi = etLokasi.getText() == null ? "" : etLokasi.getText().toString().trim();

            if (nama.isEmpty()) {
                etNama.setError("Nama wajib diisi");
                return;
            }
            if (!telepon.isEmpty() && !telepon.matches("\\+?[0-9]{8,15}")) {
                etTelepon.setError("Nomor telepon tidak valid (8-15 digit)");
                return;
            }
            db.updateProfil(session.getEmail(), nama, telepon, lokasi);
            tampilProfil();
            dialog.dismiss();
            Toast.makeText(requireContext(), "Profil diperbarui", Toast.LENGTH_SHORT).show();
        });
    }

    private void konfirmasiLogout() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Logout")
                .setMessage("Yakin ingin keluar dari akun?")
                .setPositiveButton("Ya, Keluar", (d, w) -> {
                    session.logout();
                    Intent i = new Intent(requireContext(), LoginActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .setNegativeButton("Batal", null)
                .show();
    }
}
