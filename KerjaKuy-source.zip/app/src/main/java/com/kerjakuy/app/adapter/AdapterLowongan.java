package com.kerjakuy.app.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kerjakuy.app.R;
import com.kerjakuy.app.model.Lowongan;
import com.kerjakuy.app.util.UiHelper;

import java.util.ArrayList;
import java.util.List;

public class AdapterLowongan extends RecyclerView.Adapter<AdapterLowongan.VH> {

    public interface Listener {
        void onItemClick(Lowongan lowongan, int position);
        void onFavoritClick(Lowongan lowongan, int position);
    }

    private final List<Lowongan> data = new ArrayList<>();
    private final Listener listener;
    private final boolean tampilStatus;

    public AdapterLowongan(Listener listener, boolean tampilStatus) {
        this.listener = listener;
        this.tampilStatus = tampilStatus;
    }

    public void setData(List<Lowongan> baru) {
        data.clear();
        data.addAll(baru);
        notifyDataSetChanged();
    }

    public void hapus(int position) {
        if (position >= 0 && position < data.size()) {
            data.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void ubah(int position) {
        if (position >= 0 && position < data.size()) notifyItemChanged(position);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lowongan, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Lowongan l = data.get(position);
        h.tvPosisi.setText(l.posisi);
        h.tvPerusahaan.setText(l.perusahaan);
        h.tvLokasi.setText(l.lokasi);
        h.tvGaji.setText(l.gaji);
        h.tvJenis.setText(l.jenis);
        UiHelper.pasangLogo(h.tvLogo, l.perusahaan);
        h.ivFavorit.setImageResource(l.favorit ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);

        if (tampilStatus && l.status != null) {
            h.tvStatus.setVisibility(View.VISIBLE);
            h.tvStatus.setText("Status: " + l.status + "  •  " + l.tanggal);
            h.tvStatus.setTextColor(UiHelper.warnaStatus(h.itemView.getContext(), l.status));
        } else {
            h.tvStatus.setVisibility(View.GONE);
        }

        h.itemView.setOnClickListener(v -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) listener.onItemClick(data.get(pos), pos);
        });
        h.ivFavorit.setOnClickListener(v -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) listener.onFavoritClick(data.get(pos), pos);
        });
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvLogo, tvPosisi, tvPerusahaan, tvLokasi, tvGaji, tvJenis, tvStatus;
        ImageView ivFavorit;

        VH(@NonNull View v) {
            super(v);
            tvLogo = v.findViewById(R.id.tvLogo);
            tvPosisi = v.findViewById(R.id.tvPosisi);
            tvPerusahaan = v.findViewById(R.id.tvPerusahaan);
            tvLokasi = v.findViewById(R.id.tvLokasi);
            tvGaji = v.findViewById(R.id.tvGaji);
            tvJenis = v.findViewById(R.id.tvJenis);
            tvStatus = v.findViewById(R.id.tvStatus);
            ivFavorit = v.findViewById(R.id.ivFavorit);
        }
    }
}
